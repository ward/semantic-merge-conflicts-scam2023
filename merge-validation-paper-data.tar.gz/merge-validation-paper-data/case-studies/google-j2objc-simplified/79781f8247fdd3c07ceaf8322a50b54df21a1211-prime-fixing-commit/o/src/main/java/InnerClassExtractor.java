public class InnerClassExtractor {
	public int addOuterFields(int start, boolean clazz_is_anonymous, int a, int b, int c) {
		int result = start;

		// clazz is then used in both A and B additions
		// Then follows a bunch of other stuff

		// To force it to consider paths
		if (result > 10)
			return result;
		else
			return result;
	}

	static public void main(String[] args) {
		InnerClassExtractor ice = new InnerClassExtractor();
		ice.addOuterFields(0, false, 0, 0, 0);
	}
}

class ASTFactory {
	public static int createInnerFieldDeclarations(int result, int d, int e, int f) {
		result += d;
		result += e;
		result += f;
		return result;
	}
}
