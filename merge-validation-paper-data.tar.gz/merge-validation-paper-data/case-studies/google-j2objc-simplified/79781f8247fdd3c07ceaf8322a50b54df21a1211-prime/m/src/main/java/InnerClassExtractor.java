public class InnerClassExtractor {
	public int addOuterFields(int start, boolean clazz_is_anonymous, int a, int b, int c) {

		int result = start;

		// From A side
		// In this prime version, don't have the if clazz check.
		// if (clazz_is_anonymous) {
			result = ASTFactory.createInnerFieldDeclarations(result, a, b, c);
		// }

		// From B side
		result += a;
		result += b;
		result += c;

		if (result > 10)
			return result;
		else
			return result;
	}

	static public void main(String[] args) {
		InnerClassExtractor ice = new InnerClassExtractor();
		ice.addOuterFields(0, false, 0, 0, 0);
	}
}

class ASTFactory {
	public static int createInnerFieldDeclarations(int result, int d, int e, int f) {
		result += d;
		result += e;
		result += f;
		return result;
	}
}
