import java.util.Random;
public class EditorConfigProcessor {
	public boolean applyEditorConfigRules(int key, boolean charset, boolean end_of_line, boolean insert_final_new_line, boolean tab_width) {
		boolean changedStyle = false;

		if (key == 0) { // charset
			changedStyle = changedStyle || charset;
		} else if (key == 1) { // end of line
			changedStyle = changedStyle || end_of_line;
		// simplifying it a bit cause what's the point
		// } else if (key == 2) { // indent size
		// 	changedStyle = changedStyle || false;
		// } else if (key == 3) { // indent style
		// 	changedStyle = changedStyle || false;
		} else if (key == 4) { // insert final newline
			// Disabled in B
			changedStyle = changedStyle || doInsertFinalNewLine(insert_final_new_line);
		} else if (key == 5) { // tab width added in B
			changedStyle = changedStyle || tab_width;
		}

		return changedStyle;
	}

	private boolean doInsertFinalNewLine(boolean insert_final_new_line) {
		// Implementation changes in A (added a !)
		return !insert_final_new_line;
	}

	static public void main(String[] args) {
		EditorConfigProcessor ecp = new EditorConfigProcessor();
		// Actual arguments do not matter as we will make it symbolic.
		ecp.applyEditorConfigRules(0, false, false, false, false);
	}

}
