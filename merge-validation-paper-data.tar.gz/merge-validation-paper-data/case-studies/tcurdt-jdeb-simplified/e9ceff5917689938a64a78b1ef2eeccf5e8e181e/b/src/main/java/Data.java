public final class Data {
	private MissingSrc missingSrc;

	public int produce(FakeFile src, boolean is_file, int type, boolean no_paths) {
		if (type == 444) { // LINK
			return 6664;
		}

		if (type == 555) { // TEMPLATE
			if (no_paths) {
				return 7777; // Avoiding error throwing
				// throw new RuntimeException("paths not set");
			}

			return 6665;
		}

		// TODO Do I need to rewrite this for the internal dep in the original?
		if (src == null || !src.exists(is_file)) {
			// if (missingSrc == MissingSrc.IGNORE) {
				return 6666;
			// } else {
				// throw new RuntimeException("Source not found");
			// }
		}

		if (type == 111) { // FILE
			return 6661;
		}

		if (type == 222) { // ARCHIVE
			return 6662;
		}

		if (type == 333) { // DIRECTORY
			return 6663;
		}

		throw new RuntimeException("Unknown type");
	}

	static public void main(String[] args) {
		Data d = new Data();
		d.produce(null, true, 0, true);
	}

}

enum MissingSrc {
	IGNORE,
	FAIL,
}
enum TheType {
	FILE,
	ARCHIVE,
	DIRECTORY,
	LINK,
	TEMPLATE,
}

// To get it to compile
class Receiver {
}
class DataProducerFile {
	public void produce(Receiver receiver) {
	}
}
class DataProducerArchive {
	public void produce(Receiver receiver) {
	}
}
class DataProducerDirectory {
	public void produce(Receiver receiver) {
	}
}
class DataProducerLink {
	public void produce(Receiver receiver) {
	}
}
class DataProducerTemplate {
	public void produce(Receiver receiver) {
	}
}

/* Prevents SPF from reasoning about it since it was bugging on java.io.File */
class FakeFile {
	// We're just passing on the bool, but want to take the src!=null dependency into account.
	public boolean exists(boolean is_file) {
		return is_file;
	}
}
