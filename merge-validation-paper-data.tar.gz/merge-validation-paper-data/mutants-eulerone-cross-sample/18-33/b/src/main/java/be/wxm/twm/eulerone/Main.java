package be.wxm.twm.eulerone;

// Adjusted from Euler 1 solutions
public class Main
{
	public static void main(String[] argv)
	{
    Main m = new Main();
    System.out.println(m.count_multiples(1000, 0));
	}

  public int count_multiples(int max, int start) {
		int tal = 0;
		int summa = 0;
	
		for(tal = start; tal < max; tal++)
		{
			if(tal%3 == 0)
			{
				summa += tal;
				continue;
			} 
			else if (tal / 5 == 0)
			{
				summa += tal;
			}
		}
		return summa;
  }
}
